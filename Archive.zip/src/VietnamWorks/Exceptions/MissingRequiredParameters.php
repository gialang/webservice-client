<?php
namespace VietnamWorks\Exceptions;

class MissingRequiredParameters extends \Exception{}
