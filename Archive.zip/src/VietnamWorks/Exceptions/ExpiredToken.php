<?php
namespace VietnamWorks\Exceptions;

class ExpiredToken extends \Exception{}
