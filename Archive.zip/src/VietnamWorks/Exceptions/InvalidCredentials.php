<?php
namespace VietnamWorks\Exceptions;

class InvalidCredentials extends \Exception{}
