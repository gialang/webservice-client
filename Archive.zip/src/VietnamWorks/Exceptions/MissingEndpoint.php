<?php
namespace VietnamWorks\Exceptions;

class MissingEndpoint extends \Exception{}
