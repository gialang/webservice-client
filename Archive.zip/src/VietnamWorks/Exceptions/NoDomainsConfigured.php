<?php
namespace VietnamWorks\Exceptions;

class NoDomainsConfigured extends \Exception{}
