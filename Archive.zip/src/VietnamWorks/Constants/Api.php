<?php


namespace VietnamWorks\Constants;


class Api {
    const API_USER = 'vietnamworks';
}
 